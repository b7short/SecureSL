<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Regular Expression</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    
    <div class="form">
        <h1 class="sign-up">USER NAME VALIDATION</h1>
        <!--<p class='notification'>User name validation successfull</p>-->
        <form action="index.php" method="POST">
            <input class="input" type="text" placeholder="Username" name="user-name">
            <!--<span class='error'>Only letter, number & underscore allowed and min 4, max 12</span>-->
            <input class="input btn" type="submit" value="SUBMIT" name="submit-user-name">
        </form>
    </div>

</body>
</html>